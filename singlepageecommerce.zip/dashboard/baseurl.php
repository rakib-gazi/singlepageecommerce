<?php 
$baseurl ='http://localhost/singlepageecommerce/';